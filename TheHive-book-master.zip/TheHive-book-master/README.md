![TheHive Logo](/assets/thehive-logo.png)
![WORK IN PROGRESS](https://img.shields.io/badge/Status-Work%20in%20Progress-yellow.svg)
# Introduction
In order to merge the TheHive-Project documentation repositories, this GitBook was created. Currently, this is heavily work in progress and links may not work as expected. Thanks very much for everyone involved.

# Content
- [TheHive](TheHive/README.md)
- [Cortex](Cortex/README.md)

# Download the book
- [PDF](https://www.gitbook.com/download/pdf/book/3c7/thehive-book)
- [Mobi](https://www.gitbook.com/download/mobi/book/3c7/thehive-book)
- [ePub](https://www.gitbook.com/download/epub/book/3c7/thehive-book)
