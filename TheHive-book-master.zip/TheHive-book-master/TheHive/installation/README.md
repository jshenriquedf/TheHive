# Installation guides

TheHive can be installed using:
- An [RPM package](rpm-guide.md)
- A [DEB package](deb-guide.md)
- [Docker](docker-guide.md)
- [Binary](binary-guide.md)
- [Ansible script](https://github.com/drewstinnett/ansible-thehive) contributed by
[@drewstinnett](https://github.com/drewstinnett)

TheHive can also be [built from sources](build-guide.md).
