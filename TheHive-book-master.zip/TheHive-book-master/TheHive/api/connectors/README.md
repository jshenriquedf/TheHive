# Connectors API
TheHive offers an API to manipulate its various connectors

- [Cortex](cortex)
- [MISP](misp)
- [Metrics](metrics)
