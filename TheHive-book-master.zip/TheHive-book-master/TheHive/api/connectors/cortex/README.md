# Cortex manipulation through TheHive

Cortex can be manipulated through TheHive with JSON over HTTP

- [Job](job.md)
- [Analyzer](analyzer.md)
- [Report](report.md)
