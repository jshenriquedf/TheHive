# TheHive API

TheHive exposes REST APIs through JSON over HTTP.

- [HTTP request format](request.md)
- [Authentication](authentication.md)
- [Model](model.md)
- [Alert](alert.md)
- [Case](case.md)
- [Observable](artifact.md)
- [Task](task.md)
- [Log](log.md)
- [User](user.md)
- [Connectors](connectors)
